 1) Find out 5 random Kayne West quotes  go to below link 
   http://127.0.0.1:8000/api/

 2) The API route jwt token is implemented for secure
      1st needed to registration then  check by postman 
        http://127.0.0.1:8000/api/auth/login
        http://127.0.0.1:8000/api/auth/me

 3)  DATABASE NAME = quoteapp 

