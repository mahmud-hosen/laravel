<?php echo e($slot); ?>

<?php /**PATH D:\Laravel\Laravel\quote-app\quote-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>