<p>Hi mahmud</p>

<p class="text-center">

Name:<?php echo e($first_name); ?> <br>
Last Name:<?php echo e($last_name); ?> <br>
Email :<?php echo e($email_address); ?>  <br>
Phone:<?php echo e($phone_number); ?>  <br>
Address:<?php echo e($address); ?>  <br>


</p>

<?php /**PATH D:\Ecommerce-5.8\resources\views/frontend/mail/contact.blade.php ENDPATH**/ ?>