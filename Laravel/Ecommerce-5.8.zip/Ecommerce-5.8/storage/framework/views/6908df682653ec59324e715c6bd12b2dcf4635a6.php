<?php $__env->startSection('title'); ?>
Manage Delete Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard_body'); ?>


<form action="<?php echo e(route('product_save')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <!-- Message Show -->
    <?php echo $__env->make('layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- Soft Delete Product / Show delete product -->
    <!-- ------------------------------------------ -->
<h2 class="text-center">Delete Product</h2>
    <table class="table table-border table-hover  table-responsive">
        <thead>
            <tr class="text-center">
                <th>SN</th>
                <th> Product Name</th>
                <th> Category ID</th>
                <th>product_short_description</th>
                <th> product_long_description</th>
                <th> product_price</th>
                <th> Image</th>
                <th> created_at</th>
                <th> publication_status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $soft_delete_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delete_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr class="text-center ">
                <td><?php echo e($loop->index+1); ?></td>
                <td><?php echo e($delete_product->product_name); ?></td>
                <td><?php echo e($delete_product->category_id); ?></td>
                <td><?php echo e($delete_product->product_short_description); ?></td>
                <td><?php echo e($delete_product->product_long_description); ?></td>
                <td><?php echo e($delete_product->product_price); ?></td>
                <td> <img  src="<?php echo e(asset('images/'.$delete_product->image)); ?>"  width="80" ></td>
                <td><?php echo e($delete_product->created_at); ?></td>

                <td><?php echo e($delete_product->publication_status == 1 ? 'Published': 'Unpublished'); ?></td>

                <td>
                    <div class="btn-group" role="group" aria-label="Button group">

                
                        <a href="<?php echo e(route('restore_product', $delete_product->id)); ?>" class="btn btn-success">Restore</a>
                        <a href="<?php echo e(route('force_delete_product', $delete_product->id)); ?>" class="btn btn-danger">Permanent Delete</a>

                    </div>
                </td>
            </tr>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <?php echo e($soft_delete_products->links()); ?>



</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce-5.8\resources\views/admin/product/delete_product_manage.blade.php ENDPATH**/ ?>