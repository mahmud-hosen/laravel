<?php $__env->startSection('title'); ?>
Add Category 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dashboard_body'); ?>

<form action="<?php echo e(route('category_save')); ?>" method="POST">
 <?php echo csrf_field(); ?>

 <?php echo $__env->make('layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
 
    <div class="form-group row">
        <label for="category_name" class="col-sm-2 col-form-label">Category Name</label>
        <div class="col-sm-10">
            <input type="text" name="category_name" class="form-control" id="category_name">
        </div>
    </div>

    <div class="form-group row " > 
        <label for="summary-ckeditor" class="col-sm-2 col-form-label">Category Description</label>
        <div class="col-sm-10">
            <textarea name="category_description" id="summary-ckeditor" class="form-control" rows="5"></textarea>
        </div>
    </div>

    <fieldset class="form-group">
        <div class="row">
            <legend class="col-form-label col-sm-2 pt-0">Publication Status</legend>
            <div class="col-sm-10">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="publication_status" id="publication_status" value="1">
                    <label class="form-check-label" for="publication_status">
                        Published
                    </label>
                </div>

                <div class="form-check">
                    <input class="form-check-input" type="radio" name="publication_status" id="publication_status" value="0" >
                    <label class="form-check-label" for="publication_status">
                        Unpublished
                    </label>
                </div>

            </div>
        </div>
    </fieldset>

    <div class="form-group row">
    <div class="col-sm-2"></div>
        <div class="col-sm-10">
            <button  type="submit" class="btn btn-primary"> Category Add</button>
        </div>
    </div>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce-5.8\resources\views/admin\category\category_add_form.blade.php ENDPATH**/ ?>