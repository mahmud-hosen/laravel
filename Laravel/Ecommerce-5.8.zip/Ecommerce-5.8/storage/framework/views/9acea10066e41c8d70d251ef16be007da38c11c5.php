<?php $__env->startSection('title'); ?>
Manage Product
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard_body'); ?>


<form action="<?php echo e(route('product_save')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <!-- Message Show -->
    <?php echo $__env->make('layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <table class="table table-border table-hover  table-responsive">
        <thead>
            <tr class="text-center">
                <th>SN</th>
                <th> Product Name</th>
                <th>product_short_description</th>
                <th> product_long_description</th>
                <th> product_price</th>
                <th> Image</th>
                <th> created_at</th>
                <th> publication_status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr class="text-center ">
                <td><?php echo e($loop->index+1); ?></td>
                <td><?php echo e($product->product_name); ?></td>
                <td><?php echo e($product->product_short_description); ?></td>
                <td><?php echo e($product->product_long_description); ?></td>
                <td><?php echo e($product->product_price); ?></td>
                <td> <img  src="<?php echo e(asset('images/'.$product->image)); ?>"  width="80" ></td>

                <!-- <td><?php echo e($product->created_at? $product->created_at->diffForHumans() : 'No Date'); ?></td> -->

                <td><?php echo e($product->created_at? $product->created_at->format('D-M-Y h:i:sa') : 'No Date'); ?></td>
                <td><?php echo e($product->publication_status == 1 ? 'Published': 'Unpublished'); ?></td>

                <td>
                    <div class="btn-group" role="group" aria-label="Button group">

                        <?php if($product->publication_status == 1): ?>
                        <a href="<?php echo e(route('unpublished_product', $product->id)); ?>"
                            class="btn btn-primary">Unpublished</a>
                        <?php else: ?>
                        <a href="<?php echo e(route('published_product', $product->id)); ?>"
                            class="btn btn-primary px-4">Published</a>
                        <?php endif; ?>

                        <a href="<?php echo e(route('product_delete', $product->id)); ?>" class="btn btn-danger">Delete</a>
                        <a href="<?php echo e(route('product_edit', $product->id)); ?>" class="btn btn-success">Edit</a>
                    </div>
                </td>
            </tr>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <?php echo e($products->links()); ?>



    <!-- Soft Delete Product / Show delete product -->
    <!-- ------------------------------------------ -->

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Laravel\Ecommerce-5.8\resources\views/admin/product/manage_product.blade.php ENDPATH**/ ?>