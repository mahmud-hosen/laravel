<?php $__env->startSection('title'); ?>
Order Details
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dashboard_body'); ?>




<div class="container">
    <div class="row">
        <div class="col-md-8 mx-auto mb-4">
                <h2 class="text-center">Order info for this order</h2>
            <table class="table table-hover table-bordered ">

                    <tr>
                        <th>Order No</th>
                        <td><?php echo e($customar_order->id); ?></td>
                    </tr>
                    <tr>
                        <th>Total Price  </th>
                        <td><?php echo e($customar_order->total_price); ?></td>
                    </tr>
                    <tr>
                        <th>Order Status  </th>
                        <td><?php echo e($customar_order->order_status); ?></td>
                    </tr>
					<tr>
                        <th>Payment Status  </th>
                        <td><?php echo e($customar_order->payment_status); ?></td>
                    </tr>
					<tr>
                        <th>Payment type  </th>
                        <td><?php echo e($customar_order->payment_type); ?></td>
                    </tr>
                    <tr>
                        <th>Order Date </th>
                        <td><?php echo e($customar_order->created_at); ?></td>
                    </tr>

             
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8 mx-auto mb-4">
                <h2 class="text-center">Customer info for this order</h2>
            <table class="table table-hover table-bordered ">
                    <tr>
                        <th>Customer Name </th>
                        <td><?php echo e($customar->first_name.' '.$customar->last_name); ?></td>
                    </tr>
                    <tr>
                        <th>Phone Number </th>
                        <td><?php echo e($customar->phone_number); ?></td>
                    </tr>
                    <tr>
                        <th>Email Address </th>
                        <td><?php echo e($customar->email_address); ?></td>
                    </tr>
                    <tr>
                        <th>Address </th>
                        <td><?php echo e($customar->address); ?></td>
                    </tr>
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8 mx-auto mb-4">
                <h2 class="text-center">Shipping info for this order</h2>
            <table class="table table-hover table-bordered ">
                    <tr>
                        <th>Full Name </th>
                        <td><?php echo e($shipping_info->full_name); ?></td>
                    </tr>
                    <tr>
                        <th>Phone Number </th>
                        <td><?php echo e($shipping_info->phone_number); ?></td>
                    </tr>
                    <tr>
                        <th>Email Address </th>
                        <td><?php echo e($shipping_info->email_address); ?></td>
                    </tr>
                    <tr>
                        <th>Address </th>
                        <td><?php echo e($shipping_info->address); ?></td>
                    </tr>
            </table>
        </div>
    </div>
    <div class="row">
            <div class="col-md-12 mb-5 text-center">
                    <h2 class="text-center">Product info for this order</h2>
                <table class="table table-hover table-bordered ">
                    <thead class="thead-light">
                        <tr>
                            <th>SN.</th>
                            <th>Product Id</th>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Product Price</th>
                            <th>Product Quantity</th>
                            <th>Total Price</th>
                        </tr>
                    </thead>
                    <tbody>
                    

                            <?php $__currentLoopData = $product_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($loop->index+1); ?></td>
                                <td><?php echo e($product_info->id); ?></td>
                                <td> <img  src="<?php echo e(asset('images/'.$product_info->image)); ?>"  width="50" ></td>
                                <td><?php echo e($product_info->product_name); ?></td>
                                <td><?php echo e($product_info->product_price); ?></td>
                                <td><?php echo e($product_info->product_quantity); ?></td>
                                <td><?php echo e($customar_order->total_price); ?></td>


                                
                            </tr> 




                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
            </div>
        </div>

</div>




<?php $__env->stopSection(); ?>











<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Laravel\Ecommerce-5.8\resources\views/admin\order\order_details.blade.php ENDPATH**/ ?>