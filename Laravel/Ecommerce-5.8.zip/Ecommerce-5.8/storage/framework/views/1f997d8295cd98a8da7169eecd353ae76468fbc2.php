<?php $__env->startSection('title'); ?>
Manage Category 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard_body'); ?>


<form action="<?php echo e(route('category_save')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <!-- Message Show -->
    <?php echo $__env->make('layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <table class="table table-border table-hover">
        <thead>
            <tr class="text-center">
                <th>SN</th>
                <th>Category Name</th>
                <th>Image</th>
                <th>Category Description</th>
                <th>Create Date</th>
                <th> Publication Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr class="text-center ">
                <td><?php echo e($loop->index+1); ?></td>
                <td><?php echo e($category->category_name); ?></td>
                <td> <img  src="<?php echo e(asset('admin/category/'.$category->image)); ?>"  width="80" ></td>
                <td><?php echo $category->category_description; ?></td>
                <td><?php echo e($category->created_at->diffForHumans()); ?></td>
                <!-- Condition 1==Published 0==Unpublished -->
                <td><?php echo e($category->publication_status == 1 ? 'Published': 'Unpublished'); ?></td>

                <td>
                    <div class="btn-group" role="group" aria-label="Button group">

                        <?php if($category->publication_status == 1): ?>
                        <a href="<?php echo e(route('unpublished_category', $category->id)); ?>" class="btn btn-primary">Unpublished</a>
                        <?php else: ?>
                        <a href="<?php echo e(route('published_category', $category->id)); ?>" class="btn btn-primary px-4">Published</a>
                        <?php endif; ?>

                        <a href="<?php echo e(route('category_delete', $category->id)); ?>" class="btn btn-danger">Delete</a>
                        <a href="<?php echo e(route('category_edit', $category->id)); ?>" class="btn btn-success">Edit</a>
                    </div>
                </td>

            </tr>



            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <?php echo e($categories->links()); ?>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce-5.8\resources\views/admin/category/manage_category.blade.php ENDPATH**/ ?>