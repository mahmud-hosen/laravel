<?php $__env->startSection('title'); ?>
Manage Order
<?php $__env->stopSection(); ?>


<?php $__env->startSection('dashboard_body'); ?>


<div class="container">
    <div class="row">
        <div class="col-md-12">
            <table class="table table-hover table-bordered ">
                <thead class="thead-light">
                    <tr>
                        <th>SN.</th>
                        <th>Customer Name </th>
                        <th>Total Price</th>
                        <th>Order Date </th>
                        <th>Payment Type </th>
                        <th>Payment Status</th>
                        <th>Order Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                           <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($order->id); ?></td>
                            <td><?php echo e($order->first_name.' '.$order->last_name); ?></td>
                            <td><?php echo e($order->total_price); ?></td>
                            <td><?php echo e($order->created_at); ?></td>
                            <td><?php echo e($order->payment_type); ?></td>
                            <td><?php echo e($order->payment_status); ?></td>
                            <td><?php echo e($order->order_status); ?></td>
                            <td>
                                <div class="btn-group">
                                    <a class="btn btn-info" href="<?php echo e(route('order_details',$order->id)); ?>" title="view Order details"><i class="fas fa-info"></i></a>
                                    <a class="btn btn-success" href="<?php echo e(route('order_invoice',$order->id)); ?>"title="view Order Invoice"><i class="fas fa-file-invoice"></i></a>
                                    <a class="btn btn-primary" href="" title="Order Invoice Download"><i class="fas fa-file-download"></i></a>
                                    <a class="btn btn-danger" href="" title=" Order Delete"><i class="fas fa-trash-alt"></i></a>
                                    <a class="btn btn-warning" href="" title=" Order Edit"><i class="far fa-edit"></i></a>
                                </div>
                            </td>
                        </tr> 

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

  
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Laravel\Ecommerce-5.8\resources\views/admin\order\manage_order.blade.php ENDPATH**/ ?>