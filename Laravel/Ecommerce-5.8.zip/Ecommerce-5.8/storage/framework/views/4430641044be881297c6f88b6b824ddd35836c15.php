<?php $__env->startSection('title'); ?>
Shipping Page
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>





<div class="container">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card">
                <div class="card-header  mb-3 text-center text-warning">
                    Dear <strong><?php echo e($reg_customar->first_name); ?></strong> .You have to give us product shipping info to complete your
                    valuable order.if your billing info are same then just press on save shipping info button
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8 mx-auto mb-5 ">
            <div class="card">
                <div class="card-header">
                    Shipping info goes here...
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('shipping_save')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <input id="first_name" class="form-control" type="text" name="full_name" value="<?php echo e($reg_customar->first_name); ?>"
                                placeholder="Enter your Full Name">
                        </div>
                        <div class="form-group">
                            <input id="email_address" class="form-control" type="text" name="email_address" value="<?php echo e($reg_customar->email_address); ?>"
                                placeholder="Enter Your Email">
                        </div>
                        <div class="form-group">
                            <input id="phone_number" class="form-control" type="text" name="phone_number" value="<?php echo e($reg_customar->phone_number); ?>"
                                placeholder="Enter Your Phone Number">
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" name="address" id="address" cols="30" rows="2"
                                placeholder="Enter Your full address "><?php echo e($reg_customar->address); ?></textarea>
                        </div>
                        <input class="btn btn-success btn-lg btn-block" type="submit" value="Save shipping info">
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>








<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Ecommerce-5.8\resources\views/frontend/checkout/shipping_form.blade.php ENDPATH**/ ?>