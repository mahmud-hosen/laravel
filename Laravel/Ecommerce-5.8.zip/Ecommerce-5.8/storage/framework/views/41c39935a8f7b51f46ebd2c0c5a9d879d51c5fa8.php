
<section>

<h2>Chat Messages</h2>

<div class="container">
  <img src="/images/1602858243.jpg" alt="Avatar" style="width:100%;">
  
  <p>Hello. How are you today?</p>
  <span class="time-right">11:00</span>
</div>

</section>


<div class="container darker">
  <img src="/w3images/avatar_g2.jpg" alt="Avatar" class="right" style="width:100%;">
  <p>Hey! I'm fine. Thanks for asking!</p>
  <span  class="time-left">11:01</span>
</div>




<?php /**PATH D:\Ecommerce-5.8\resources\views/frontend/comment/comment.blade.php ENDPATH**/ ?>