<?php $__env->startSection('title'); ?>
Manage Brand 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboard_body'); ?>


<form action="<?php echo e(route('brand_save')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <!-- Message Show -->
    <?php echo $__env->make('layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <table class="table table-border table-hover">
        <thead>
            <tr class="text-center">
                <th>SN</th>
                <th>Brand Name</th>
                <th>Image</th>
                <th>Brand Description</th>
                <th>Create Date</th>
                <th> Publication Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>

            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



            <tr class="text-center ">
                <td><?php echo e($loop->index+1); ?></td>
                <td><?php echo e($brand->brand_name); ?></td>
                <td> <img  src="<?php echo e(asset('admin/brand/'.$brand->image)); ?>"  width="80" ></td>
                <td><?php echo $brand->brand_description; ?></td>
                <td><?php echo e($brand->created_at->diffForHumans()); ?></td>
                <!-- Condition 1==Published 0==Unpublished -->
                <td><?php echo e($brand->publication_status == 1 ? 'Published': 'Unpublished'); ?></td>

                <td>
                    <div class="btn-group" role="group" aria-label="Button group">

                        <?php if($brand->publication_status == 1): ?>
                        <a href="<?php echo e(route('unpublished_brand', $brand->id)); ?>" class="btn btn-primary">Unpublished</a>
                        <?php else: ?>
                        <a href="<?php echo e(route('published_brand', $brand->id)); ?>" class="btn btn-primary px-4">Published</a>
                        <?php endif; ?>

                        <a href="<?php echo e(route('brand_delete', $brand->id)); ?>" class="btn btn-danger">Delete</a>
                        <a href="<?php echo e(route('brand_edit', $brand->id)); ?>" class="btn btn-success">Edit</a>
                    </div>
                </td>

            </tr>



            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
    <?php echo e($brands->links()); ?>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\Laravel\Ecommerce-5.8\resources\views/admin\brand\manage_brand.blade.php ENDPATH**/ ?>