<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customar extends Model
{
    //
}
