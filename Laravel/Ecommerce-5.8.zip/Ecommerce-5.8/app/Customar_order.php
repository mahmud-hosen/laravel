<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customar_order extends Model
{
    //
}
