<p>Hi mahmud</p>

<p >

Name:{{$first_name}} <br>
Last Name:{{$last_name}} <br>
Email :{{$email_address}}  <br>
Phone:{{$phone_number}}  <br>
Address:{{$address}}  <br>


</p>

